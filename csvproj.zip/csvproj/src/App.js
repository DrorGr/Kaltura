import "./App.css";
import { useState } from "react";
import Papa from "papaparse";



function App() {
  const [date, setDate] = useState("");
  const [revenue, setRevenue] =  useState(0);
  const [capacity, setCapacity] = useState();
  const [loaded, setLoaded] = useState(false);


  const changeHandler = (event) => {
    Papa.parse(event.target.files[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (results) {

       let newData =results.data.filter((obj)=>{
          return  obj[" Start Day"].substring(0,8)==` ${date}`
          })
        
        setRevenue(newData.reduce((accumulator, object) => {
          return accumulator + +object[" Monthly Price"];
        }, 0));

        setCapacity(newData.reduce((accumulator, object) => {
          return accumulator + +object.Capacity;
        }, 0));
        
        setLoaded(true);
      }
    });
  };

  return (
    <div className="Main_Container">
      <div className="Buttons_Container">
      <input
        type="file"
        name="file"
        onChange={changeHandler}
        accept=".csv"
        />
      <input
      type="month"
      onChange={e=> setDate(e.target.value)}
      />
      </div>
      <br />
        <div className="data">
        {loaded == false && <p> Please choose a date and upload the currect file</p>}
        {loaded == true && <p>{date}: expected revenue: ${revenue}, expected total capacity of the unreserved offices: {capacity}</p>}
        </div>
    </div>
  );
}


export default App;
